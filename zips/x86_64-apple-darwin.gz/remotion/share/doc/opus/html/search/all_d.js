var searchData=
[
  ['values_20for_20ctl_20interface_0',['Pre-defined values for CTL interface',['../group__opus__ctlvalues.html',1,'']]]
];
