var searchData=
[
  ['codes_0',['Error codes',['../group__opus__errorcodes.html',1,'']]],
  ['ctl_20interface_1',['Pre-defined values for CTL interface',['../group__opus__ctlvalues.html',1,'']]],
  ['ctls_2',['CTLs',['../group__opus__decoderctls.html',1,'Decoder related CTLs'],['../group__opus__encoderctls.html',1,'Encoder related CTLs'],['../group__opus__genericctls.html',1,'Generic CTLs'],['../group__opus__multistream__ctls.html',1,'Multistream specific encoder and decoder CTLs']]],
  ['custom_3',['Opus Custom',['../group__opus__custom.html',1,'']]]
];
