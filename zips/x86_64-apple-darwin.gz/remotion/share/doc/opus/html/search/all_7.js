var searchData=
[
  ['library_20information_20functions_0',['Opus library information functions',['../group__opus__libinfo.html',1,'']]]
];
