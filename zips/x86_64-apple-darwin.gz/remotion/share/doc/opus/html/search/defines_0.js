var searchData=
[
  ['opus_5fcustom_5fexport_0',['OPUS_CUSTOM_EXPORT',['../opus__custom_8h.html#a92c66b86b701421b674984559e79bbf0',1,'opus_custom.h']]],
  ['opus_5fcustom_5fexport_5fstatic_1',['OPUS_CUSTOM_EXPORT_STATIC',['../opus__custom_8h.html#a83ea1aac7766a02abc5c666516b2e622',1,'opus_custom.h']]],
  ['opus_5fint_2',['opus_int',['../opus__types_8h.html#af3ad92331bd12b4fb4ffd0f63599d76a',1,'opus_types.h']]],
  ['opus_5fint64_3',['opus_int64',['../opus__types_8h.html#ab6742070cf9d0ccffca2b80522b4f41a',1,'opus_types.h']]],
  ['opus_5fint8_4',['opus_int8',['../opus__types_8h.html#aa3680a0b88ed316512ba749abe4c11c5',1,'opus_types.h']]],
  ['opus_5fuint_5',['opus_uint',['../opus__types_8h.html#a495e53c6b5deb68cf24f5c79651bd6c8',1,'opus_types.h']]],
  ['opus_5fuint64_6',['opus_uint64',['../opus__types_8h.html#a8291e2e41535338d13cd74868cb8e86d',1,'opus_types.h']]],
  ['opus_5fuint8_7',['opus_uint8',['../opus__types_8h.html#a40a7748a424a3453dc79f3838c5dbddc',1,'opus_types.h']]]
];
