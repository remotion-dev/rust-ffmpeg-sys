var searchData=
[
  ['encoder_0',['Opus Encoder',['../group__opus__encoder.html',1,'']]],
  ['encoder_20and_20decoder_20ctls_1',['Multistream specific encoder and decoder CTLs',['../group__opus__multistream__ctls.html',1,'']]],
  ['encoder_20related_20ctls_2',['Encoder related CTLs',['../group__opus__encoderctls.html',1,'']]],
  ['error_20codes_3',['Error codes',['../group__opus__errorcodes.html',1,'']]]
];
