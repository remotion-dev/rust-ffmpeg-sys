var searchData=
[
  ['decoder_0',['Opus Decoder',['../group__opus__decoder.html',1,'']]],
  ['decoder_20ctls_1',['Multistream specific encoder and decoder CTLs',['../group__opus__multistream__ctls.html',1,'']]],
  ['decoder_20related_20ctls_2',['Decoder related CTLs',['../group__opus__decoderctls.html',1,'']]],
  ['defined_20values_20for_20ctl_20interface_3',['Pre-defined values for CTL interface',['../group__opus__ctlvalues.html',1,'']]]
];
