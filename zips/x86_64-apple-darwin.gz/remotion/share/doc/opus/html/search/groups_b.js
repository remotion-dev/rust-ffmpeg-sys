var searchData=
[
  ['related_20ctls_0',['related CTLs',['../group__opus__decoderctls.html',1,'Decoder related CTLs'],['../group__opus__encoderctls.html',1,'Encoder related CTLs']]],
  ['repacketizer_1',['Repacketizer',['../group__opus__repacketizer.html',1,'']]]
];
