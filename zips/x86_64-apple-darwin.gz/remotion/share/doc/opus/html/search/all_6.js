var searchData=
[
  ['information_20functions_0',['Opus library information functions',['../group__opus__libinfo.html',1,'']]],
  ['interface_1',['Pre-defined values for CTL interface',['../group__opus__ctlvalues.html',1,'']]]
];
