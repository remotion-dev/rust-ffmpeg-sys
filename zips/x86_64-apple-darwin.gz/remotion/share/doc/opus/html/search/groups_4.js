var searchData=
[
  ['for_20ctl_20interface_0',['Pre-defined values for CTL interface',['../group__opus__ctlvalues.html',1,'']]],
  ['functions_1',['Opus library information functions',['../group__opus__libinfo.html',1,'']]]
];
