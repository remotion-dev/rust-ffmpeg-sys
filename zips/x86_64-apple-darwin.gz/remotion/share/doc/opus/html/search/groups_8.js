var searchData=
[
  ['multistream_20api_0',['Opus Multistream API',['../group__opus__multistream.html',1,'']]],
  ['multistream_20specific_20encoder_20and_20decoder_20ctls_1',['Multistream specific encoder and decoder CTLs',['../group__opus__multistream__ctls.html',1,'']]]
];
